function det_B=compute_det_B(Un_t,p,beta)

Le=-8;  Re=8;  Be=-8;  Te=8;  Nx=16*8;  Ny=16*8;  area=(Re-Le)*(Te-Be);  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
freqx=(pi/(Re-Le))*(1:Nx-1)';  freqy=(pi/(Te-Be))*(1:Ny-1)';  [Freqx,Freqy]=meshgrid(freqx,freqy);
Kxxyy=(-1)*(Freqx.^2+Freqy.^2);  L=0.5*Kxxyy;  
gammax=1;  gammay=1;  w0=4;  delta=1;  r0=1;
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));

    tau=1/10000;
    
    if (p==2)
        A=[0 0;1/2 0];  c=[0;1/2];  b1=[0 1];  b2=[1/2 1/2];  s=size(A,1); 
        Matrix(:,:,1)=exp(c(2)*tau*L);
        Matrix(:,:,2)=exp((c(2)-c(1))*tau*L);
        Matrix(:,:,3)=exp(tau*L);
        Matrix(:,:,4)=exp((1-c(1))*tau*L);
        Matrix(:,:,5)=exp((1-c(2))*tau*L);
    elseif (p==3)
        A=[0 0 0;1/3 0 0;0 2/3 0];  c=[0;1/3;2/3];  b1=[1/4 0 3/4];  b2=[1/3 1/3 1/3];  s=size(A,1);
        Matrix(:,:,1)=exp(c(2)*tau*L);
        Matrix(:,:,2)=exp((c(2)-c(1))*tau*L);
        Matrix(:,:,3)=exp(c(3)*tau*L);
        Matrix(:,:,4)=exp((c(3)-c(1))*tau*L);
        Matrix(:,:,5)=exp((c(3)-c(2))*tau*L);
        Matrix(:,:,6)=exp(tau*L);
        Matrix(:,:,7)=exp((1-c(1))*tau*L);
        Matrix(:,:,8)=exp((1-c(2))*tau*L);
        Matrix(:,:,9)=exp((1-c(3))*tau*L);
    elseif (p==4)
        A=[0 0 0 0;1/2 0 0 0;0 1/2 0 0;0 0 1 0];  c=[0;1/2;1/2;1];  b1=[1/6 1/3 1/3 1/6];  b2=[0 0 0 1];  s=size(A,1);
        Matrix(:,:,1)=exp(c(2)*tau*L);
        Matrix(:,:,2)=exp((c(2)-c(1))*tau*L);
        Matrix(:,:,3)=exp(c(3)*tau*L);
        Matrix(:,:,4)=exp((c(3)-c(1))*tau*L);
        Matrix(:,:,5)=exp((c(3)-c(2))*tau*L);
        Matrix(:,:,6)=exp(c(4)*tau*L);
        Matrix(:,:,7)=exp((c(4)-c(1))*tau*L);
        Matrix(:,:,8)=exp((c(4)-c(2))*tau*L);
        Matrix(:,:,9)=exp((c(4)-c(3))*tau*L);
        Matrix(:,:,10)=exp(tau*L);
        Matrix(:,:,11)=exp((1-c(1))*tau*L);
        Matrix(:,:,12)=exp((1-c(2))*tau*L);
        Matrix(:,:,13)=exp((1-c(3))*tau*L);
        Matrix(:,:,14)=exp((1-c(4))*tau*L);
    end

    dstcoe=4/Nx/Ny;  idstcoe=Nx*Ny/4;

    Umid_t=zeros(Ny-1,Nx-1,s);  Umid=zeros(Ny-1,Nx-1,s);  mumid=zeros(1,s);  Fmid=zeros(Ny-1,Nx-1,s); 

    Umid_t(:,:,1)=Un_t;  Umid(:,:,1)=idstcoe*idst2(Umid_t(:,:,1));
    mumid(1)=((-0.25)*area*sum(sum(Umid_t(:,:,1).*L.*Umid_t(:,:,1)))+hx*hy*sum(sum(V.*(Umid(:,:,1).^2)))+hx*hy*beta*sum(sum(Umid(:,:,1).^4)))/(0.25*area*sum(sum(Umid_t(:,:,1).*Umid_t(:,:,1))));
    Fmid(:,:,1)=dstcoe*dst2(-V.*Umid(:,:,1)-beta*Umid(:,:,1).^3)+mumid(1)*Umid_t(:,:,1);
    for k=2:s
        Umid_t(:,:,k)=Matrix(:,:,(k*(k-1))/2).*Un_t+tau*sum((Matrix(:,:,(k*(k-1))/2+1:(k*(k-1))/2+k-1).*Fmid(:,:,1:k-1)).*(reshape(A(k,1:k-1),1,1,k-1)),3);  Umid(:,:,k)=idstcoe*idst2(Umid_t(:,:,k));
        mumid(k)=((-0.25)*area*sum(sum(Umid_t(:,:,k).*L.*Umid_t(:,:,k)))+hx*hy*sum(sum(V.*(Umid(:,:,k).^2)))+hx*hy*beta*sum(sum(Umid(:,:,k).^4)))/(0.25*area*sum(sum(Umid_t(:,:,k).*Umid_t(:,:,k))));
        Fmid(:,:,k)=dstcoe*dst2(-V.*Umid(:,:,k)-beta*Umid(:,:,k).^3)+mumid(k)*Umid_t(:,:,k);
    end
    Unext1_t=Matrix(:,:,(s*(s+1))/2).*Un_t+tau*sum((Matrix(:,:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid).*(reshape(b1,1,1,s)),3);  d1_t=Unext1_t-Un_t;
    Unext2_t=Matrix(:,:,(s*(s+1))/2).*Un_t+tau*sum((Matrix(:,:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid).*(reshape(b2,1,1,s)),3);  d2_t=Unext2_t-Un_t;

    Unext1d1=0.25*area*sum(sum(Unext1_t.*d1_t));
    Unext1d2=0.25*area*sum(sum(Unext1_t.*d2_t));
    Utmid=L.*Umid_t+Fmid;  key=-0.5*tau*area*sum(sum(sum(Utmid.*Utmid.*(reshape(b1,1,1,s)))));
    Unext1Ld1=-0.25*area*sum(sum(Unext1_t.*L.*d1_t));
    Unext1Ld2=-0.25*area*sum(sum(Unext1_t.*L.*d2_t));

    Un1_t=Unext1_t;  Un1=idstcoe*idst2(Un1_t);
    d1=idstcoe*idst2(d1_t);  d2=idstcoe*idst2(d2_t);
    BB=(1/tau/tau)*[2*Unext1d1 2*Unext1d2; ...
                    2*Unext1Ld1+hx*hy*sum(sum(2*V.*Un1.*d1+2*beta*(Un1.^3).*d1))-key 2*Unext1Ld2+hx*hy*sum(sum(2*V.*Un1.*d2+2*beta*(Un1.^3).*d2))-key;];
    det_B=det(BB); 