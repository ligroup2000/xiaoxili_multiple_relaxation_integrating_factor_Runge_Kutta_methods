function Un_t=Gauss(tau)
warning off;

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

T=0.5;  Le=-8;  Re=8;  Be=-8;  Te=8;  Nx=16*8;  Ny=16*8;  area=(Re-Le)*(Te-Be);  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
freqx=(pi/(Re-Le))*(1:Nx-1)';  freqy=(pi/(Te-Be))*(1:Ny-1)';  [Freqx,Freqy]=meshgrid(freqx,freqy);
Kxxyy=(-1)*(Freqx.^2+Freqy.^2);  L=0.5*Kxxyy;  
gammax=1;  gammay=1;  w0=4;  delta=1;  r0=1;  beta=50;  
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));

dstcoe=4/Nx/Ny;  idstcoe=Nx*Ny/4;
Un=(((gammax*gammay)^(1/4))/((pi)^(1/2)))*exp(-0.5*(gammax*xmesh.^2+gammay*Ymesh.^2));  Un_t=dstcoe*dst2(Un);  Un_t_f=Un_t(:); 

s=size(A,1);  Umid=zeros(Ny-1,Nx-1,s);  fmid_t=Umid;  Gmid=Umid;
Matrix=(speye(s*(Nx-1)*(Ny-1))-tau*kron(A,spdiags(L(:),0,(Nx-1)*(Ny-1),(Nx-1)*(Ny-1))))^(-1);  
for k=1:round(T/tau)
    iter_err=1;  iter_count=0;  eUn_t_f=kron(ones(s,1),Un_t_f);  Umid_t_f=eUn_t_f;
    while ((iter_err>10^(-14)) && (iter_count<100))
        Umid_t=reshape(Umid_t_f,Ny-1,Nx-1,s);  
        for kk=1:s
            Umid(:,:,kk)=idstcoe*idst2(Umid_t(:,:,kk));
        end 
        fmid=-V.*Umid-beta*Umid.^3;
        for kk=1:s
            fmid_t(:,:,kk)=dstcoe*dst2(fmid(:,:,kk));
        end
        mumid=((-0.25)*area*sum(sum(Umid_t.*L.*Umid_t))+hx*hy*sum(sum(V.*(Umid.^2)))+hx*hy*beta*sum(sum(Umid.^4))) ...
              ./(0.25*area*sum(sum(Umid_t.^2)));
        Fmid_t=fmid_t+Umid_t.*mumid;
        for kk=1:s
            Gmid(:,:,kk)=sum(Fmid_t.*reshape(A(kk,:),1,1,s),3);
        end
        Umid_t_f_save=Umid_t_f;  Umid_t_f=Matrix*(eUn_t_f+tau*Gmid(:));
        iter_err=max(abs(Umid_t_f_save-Umid_t_f));  
        iter_count=iter_count+1;
    end
    k
    Umid_t=reshape(Umid_t_f,Ny-1,Nx-1,s);  
    for kk=1:s
        Umid(:,:,kk)=idstcoe*idst2(Umid_t(:,:,kk));
    end 
    fmid=-V.*Umid-beta*Umid.^3;
    for kk=1:s
        fmid_t(:,:,kk)=dstcoe*dst2(fmid(:,:,kk));
    end
    mumid=((-0.25)*area*sum(sum(Umid_t.*L.*Umid_t))+hx*hy*sum(sum(V.*(Umid.^2)))+hx*hy*beta*sum(sum(Umid.^4))) ...
          ./(0.25*area*sum(sum(Umid_t.^2)));
    Fmid_t=fmid_t+Umid_t.*mumid;
    Un_t=Un_t+tau*sum(L.*Umid_t.*reshape(b,1,1,s),3)+tau*sum(Fmid_t.*reshape(b,1,1,s),3);  Un_t_f=Un_t(:);
end