function [err,Energy1_average,CPU_time,ave_step]=RIFRK2(tau)
tic;
T=0.5;  Le=-8;  Re=8;  Be=-8;  Te=8;  Nx=16*4;  Ny=16*4;  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  h=hx*hy;
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
Kxx=(1/hx/hx)*(spdiags(-2*ones(Nx-1,1),0,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),1,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),-1,Nx-1,Nx-1)); 
Kyy=(1/hy/hy)*(spdiags(-2*ones(Ny-1,1),0,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),1,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),-1,Ny-1,Ny-1));
Kxxyy=kron(Kxx,speye(Ny-1,Ny-1))+kron(speye(Nx-1,Nx-1),Kyy);
gammax=1;  gammay=1;  w0=4;  delta=1;  r0=1;  beta=50;  
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));  V=V(:);
L=0.5*Kxxyy;

A=[0 0;1/2 0];  c=[0;1/2];  b1=[0 1];  
b2=[1/2 1/2]; 
II=speye((Nx-1)*(Ny-1),(Nx-1)*(Ny-1));
MM=c(2)*tau*L;  M2=II+MM+0.5*MM^2;
MM=(c(2)-c(1))*tau*L;  M21=II+MM+0.5*MM^2;
MM=tau*L;  Mnext=II+MM+0.5*MM^2;
MM=(1-c(1))*tau*L;  Mnext1=II+MM+0.5*MM^2;
MM=(1-c(2))*tau*L;  Mnext2=II+MM+0.5*MM^2;
 
Un=(((gammax*gammay)^(1/4))/((pi)^(1/2)))*exp(-0.5*(gammax*xmesh.^2+gammay*Ymesh.^2));  Un=Un(:);
Energy1=h*sum(Un.*Un); 
Energy2=-h*(Un'*L*Un)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4);  
tn=0;

Umid=zeros((Nx-1)*(Ny-1),2);  mumid=zeros(1,2);  Fmid=zeros((Nx-1)*(Ny-1),2);  num_of_step=0;
while (tn<(T-tau))
    Umid(:,1)=Un;
    mumid(1)=(-(Umid(:,1)'*L*Umid(:,1))+sum(V.*(Umid(:,1).^2))+beta*sum(Umid(:,1).^4))/(sum(Umid(:,1).*Umid(:,1)));
    Fmid(:,1)=-V.*Umid(:,1)-beta*Umid(:,1).^3+mumid(1)*Umid(:,1);
   
    Umid(:,2)=M2*Un+tau*A(2,1)*M21*Fmid(:,1);
    mumid(2)=(-(Umid(:,2)'*L*Umid(:,2))+sum(V.*(Umid(:,2).^2))+beta*sum(Umid(:,2).^4))/(sum(Umid(:,2).*Umid(:,2)));
    Fmid(:,2)=-V.*Umid(:,2)-beta*Umid(:,2).^3+mumid(2)*Umid(:,2);

    Unext1=Mnext*Un+tau*(b1(1)*Mnext1*Fmid(:,1)+b1(2)*Mnext2*Fmid(:,2));  d1=Unext1-Un;
    
    if (max(abs(d1))==0)
        gamma=[0;0];
    else 
        Unext2=Mnext*Un+tau*(b2(1)*Mnext1*Fmid(:,1)+b2(2)*Mnext2*Fmid(:,2));  d2=Unext2-Un;
        gamma=compute_gamma(Energy1(1),Energy2(end),Unext1,d1,d2,h,V,beta,L,Umid,Fmid,tau,b1);
    end
    % fprintf('tn=%d,gamma1=%d,gamma2=%d\n',tn,gamma(1),gamma(2));
    Un_save=Un;  tn_save=tn; 
    Un=Unext1+gamma(1)*d1+gamma(2)*d2;  tn=tn+(1+sum(gamma))*tau;  
    Energy1=[Energy1 h*sum(Un.*Un)];
    Energy2=[Energy2 -h*sum(Un'*L*Un)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4)]; 
    num_of_step=num_of_step+1;
end


if ( (T-tn)<=0 ) 
    Energy1=Energy1(1:end-1);  
    Energy2=Energy2(1:end-1);  
    Un=Un_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end

MM=c(2)*tau*L;  M2=II+MM+0.5*MM^2;
MM=(c(2)-c(1))*tau*L;  M21=II+MM+0.5*MM^2;
MM=tau*L;  Mnext=II+MM+0.5*MM^2;
MM=(1-c(1))*tau*L;  Mnext1=II+MM+0.5*MM^2;
MM=(1-c(2))*tau*L;  Mnext2=II+MM+0.5*MM^2;

Umid(:,1)=Un;
mumid(1)=(-(Umid(:,1)'*L*Umid(:,1))+sum(V.*(Umid(:,1).^2))+beta*sum(Umid(:,1).^4))/(sum(Umid(:,1).*Umid(:,1)));
Fmid(:,1)=-V.*Umid(:,1)-beta*Umid(:,1).^3+mumid(1)*Umid(:,1);

Umid(:,2)=M2*Un+tau*A(2,1)*M21*Fmid(:,1);
mumid(2)=(-(Umid(:,2)'*L*Umid(:,2))+sum(V.*(Umid(:,2).^2))+beta*sum(Umid(:,2).^4))/(sum(Umid(:,2).*Umid(:,2)));
Fmid(:,2)=-V.*Umid(:,2)-beta*Umid(:,2).^3+mumid(2)*Umid(:,2);

Un=Mnext*Un+tau*(b1(1)*Mnext1*Fmid(:,1)+b1(2)*Mnext2*Fmid(:,2));  tn=tn+tau;  num_of_step=num_of_step+1;

toc;  CPU_time=toc;
load reference.mat;  err=max(abs(Un-Un_10000));
Energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
ave_step=CPU_time/num_of_step;