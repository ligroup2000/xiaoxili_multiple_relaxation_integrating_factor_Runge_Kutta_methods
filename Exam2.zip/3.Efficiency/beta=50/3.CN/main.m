stepsize=[1/20 1/40 1/80 1/160 1/320 1/640 1/1280];

ERR=[];  Energy1=[];  CPU_TIME=[];  AVR_STEP=[];
for k=1:size(stepsize,2)
    ERR_AVE=[];  Energy1_AVE=[];  CPU_TIME_AVE=[];  AVR_STEP_AVE=[];
    for kk=1:10
        [err,Energy1_average,CPU_time,ave_step]=CN(stepsize(k));
        ERR_AVE=[ERR_AVE err];  Energy1_AVE=[Energy1_AVE Energy1_average];  CPU_TIME_AVE=[CPU_TIME_AVE CPU_time];  AVR_STEP_AVE=[AVR_STEP_AVE ave_step]; 
    end
    ERR=[ERR mean(ERR_AVE)];
    Energy1=[Energy1 mean(Energy1_AVE)];
    CPU_TIME=[CPU_TIME mean(CPU_TIME_AVE)];
    AVR_STEP=[AVR_STEP mean(AVR_STEP_AVE)];
end

err_order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))