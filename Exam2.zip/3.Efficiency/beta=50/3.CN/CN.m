function [err,Energy1_average,CPU_time,ave_step]=CN(tau)
tic;
T=0.5;  Le=-8;  Re=8;  Be=-8;  Te=8;  Nx=16*4;  Ny=16*4;  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  h=hx*hy;
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
Kxx=(1/hx/hx)*(spdiags(-2*ones(Nx-1,1),0,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),1,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),-1,Nx-1,Nx-1)); 
Kyy=(1/hy/hy)*(spdiags(-2*ones(Ny-1,1),0,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),1,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),-1,Ny-1,Ny-1));
Kxxyy=kron(Kxx,speye(Ny-1,Ny-1))+kron(speye(Nx-1,Nx-1),Kyy);
gammax=1;  gammay=1;  w0=4;  delta=1;  r0=1;  beta=50;  
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));  V=V(:);
L=0.5*Kxxyy;
 
Un=(((gammax*gammay)^(1/4))/((pi)^(1/2)))*exp(-0.5*(gammax*xmesh.^2+gammay*Ymesh.^2));  Un=Un(:);
Energy1=h*sum(Un.*Un); 
Energy2=-h*(Un'*L*Un)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4);  

for k=1:round(T/tau)
    iter_err=1;  iter_count=0;  Un1=Un;
    while ((iter_err>10^(-14)) && (iter_count<5))
        Umid=0.5*(Un+Un1);
        mu=(-(Umid'*L*Umid)+sum(V.*Umid.^2)+0.5*beta*sum((Un1.^2+Un.^2).*Umid.^2))/(sum(Umid.^2));
        F=((1/tau)*speye((Nx-1)*(Ny-1),(Nx-1)*(Ny-1))+0.5*L)*Un-V.*Umid-0.5*beta*(Un1.^2+Un.^2).*Umid+mu*Umid;
        Un1_save=Un1;  Un1=((1/tau)*speye((Nx-1)*(Ny-1),(Nx-1)*(Ny-1))-0.5*L)\F;
        iter_err=max(abs(Un1_save-Un1));  iter_count=iter_count+1;
    end
    Un=Un1;
    Energy1=[Energy1 h*sum(Un.*Un)];
    Energy2=[Energy2 -h*(Un'*L*Un)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4)];
end

toc;  

CPU_time=toc;
load reference.mat;  err=max(abs(Un-Un_10000));
Energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
ave_step=CPU_time/(T/tau);