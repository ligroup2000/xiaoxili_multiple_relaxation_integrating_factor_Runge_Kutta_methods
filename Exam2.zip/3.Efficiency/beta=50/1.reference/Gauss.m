tau=1/10000;
w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];

T=0.5;  Le=-8;  Re=8;  Be=-8;  Te=8;  Nx=16*4;  Ny=16*4;  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  h=hx*hy;
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
Kxx=(1/hx/hx)*(spdiags(-2*ones(Nx-1,1),0,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),1,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),-1,Nx-1,Nx-1)); 
Kyy=(1/hy/hy)*(spdiags(-2*ones(Ny-1,1),0,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),1,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),-1,Ny-1,Ny-1));
Kxxyy=kron(Kxx,speye(Ny-1,Ny-1))+kron(speye(Nx-1,Nx-1),Kyy);
gammax=1;  gammay=1;  w0=4;  delta=1;  r0=1;  beta=50;  
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));  V=V(:);
L=0.5*Kxxyy;

Un=(((gammax*gammay)^(1/4))/((pi)^(1/2)))*exp(-0.5*(gammax*xmesh.^2+gammay*Ymesh.^2));  Un=Un(:);

s=size(A,1);  % Matrix=(speye(s*(Nx-1)*(Ny-1))-tau*kron(A,L))^(-1);  
for k=1:round(T/tau)
    iter_err=1;  iter_count=0;  eUn=kron(ones(s,1),Un);  Umid=eUn;
    while ((iter_err>10^(-14)) && (iter_count<100))
        Umid_reshape=reshape(Umid,(Nx-1)*(Ny-1),s);
        fmid_reshape=-V.*Umid_reshape-beta*Umid_reshape.^3;
        temp=[Umid_reshape(:,1)'*L*Umid_reshape(:,1) ...
              Umid_reshape(:,2)'*L*Umid_reshape(:,2) ...
              Umid_reshape(:,3)'*L*Umid_reshape(:,3) ...
              Umid_reshape(:,4)'*L*Umid_reshape(:,4)];
        mumid=(-h*temp+h*sum(V.*Umid_reshape.^2)+h*beta*sum(Umid_reshape.^4)) ...
              ./(h*sum(Umid_reshape.^2));
        Fmid_reshape=fmid_reshape+Umid_reshape*diag(mumid);
        Gmid=Fmid_reshape*A';
        Umid_save=Umid;  Umid=(speye(s*(Nx-1)*(Ny-1))-tau*kron(A,L))\(eUn+tau*Gmid(:));
        iter_err=max(abs(Umid_save-Umid));  
        iter_count=iter_count+1;
    end
    iter_err
    k
    Umid_reshape=reshape(Umid,(Nx-1)*(Ny-1),s);
    fmid_reshape=-V.*Umid_reshape-beta*Umid_reshape.^3;
    temp=[Umid_reshape(:,1)'*L*Umid_reshape(:,1) ...
          Umid_reshape(:,2)'*L*Umid_reshape(:,2) ...
          Umid_reshape(:,3)'*L*Umid_reshape(:,3) ...
          Umid_reshape(:,4)'*L*Umid_reshape(:,4)];
    mumid=(-h*temp+h*sum(V.*Umid_reshape.^2)+h*beta*sum(Umid_reshape.^4)) ...
          ./(h*sum(Umid_reshape.^2));
    Fmid_reshape=fmid_reshape+Umid_reshape*diag(mumid);
    Un=Un+tau*L*Umid_reshape*b'+tau*Fmid_reshape*b';
end
Un_10000=Un;
save('reference.mat','Un_10000');