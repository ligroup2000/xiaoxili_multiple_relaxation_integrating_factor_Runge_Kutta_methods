function [err,Energy1_average,CPU_time,ave_step]=RIFRK3(tau)
tic;
T=0.5;  Le=-8;  Re=8;  Be=-8;  Te=8;  Nx=16*4;  Ny=16*4;  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  h=hx*hy;
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
Kxx=(1/hx/hx)*(spdiags(-2*ones(Nx-1,1),0,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),1,Nx-1,Nx-1)+spdiags(ones(Nx-1,1),-1,Nx-1,Nx-1)); 
Kyy=(1/hy/hy)*(spdiags(-2*ones(Ny-1,1),0,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),1,Ny-1,Ny-1)+spdiags(ones(Ny-1,1),-1,Ny-1,Ny-1));
Kxxyy=kron(Kxx,speye(Ny-1,Ny-1))+kron(speye(Nx-1,Nx-1),Kyy);
gammax=1;  gammay=1;  w0=4;  delta=1;  r0=1;  beta=25;  
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));  V=V(:);
L=0.5*Kxxyy; 

A=[0 0 0;1/3 0 0;0 2/3 0];  c=[0;1/3;2/3];  b1=[1/4 0 3/4];  
b2=[1/3 1/3 1/3];
II=speye((Nx-1)*(Ny-1),(Nx-1)*(Ny-1));
MM=c(2)*tau*L;  M2=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(c(2)-c(1))*tau*L;  M21=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=c(3)*tau*L;  M3=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(c(3)-c(1))*tau*L;  M31=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(c(3)-c(2))*tau*L;  M32=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=tau*L;  Mnext=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(1-c(1))*tau*L;  Mnext1=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(1-c(2))*tau*L;  Mnext2=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(1-c(3))*tau*L;  Mnext3=II+MM+0.5*MM^2+(1/6)*MM^3;
 
Un=(((gammax*gammay)^(1/4))/((pi)^(1/2)))*exp(-0.5*(gammax*xmesh.^2+gammay*Ymesh.^2));  Un=Un(:);
Energy1=h*sum(Un.*Un); 
Energy2=-h*(Un'*L*Un)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4);  
tn=0;

Umid=zeros((Nx-1)*(Ny-1),2);  mumid=zeros(1,2);  Fmid=zeros((Nx-1)*(Ny-1),2);  num_of_step=0;
while (tn<(T-tau))
    Umid(:,1)=Un;
    mumid(1)=(-(Umid(:,1)'*L*Umid(:,1))+sum(V.*(Umid(:,1).^2))+beta*sum(Umid(:,1).^4))/(sum(Umid(:,1).*Umid(:,1)));
    Fmid(:,1)=-V.*Umid(:,1)-beta*Umid(:,1).^3+mumid(1)*Umid(:,1);
   
    Umid(:,2)=M2*Un+tau*A(2,1)*M21*Fmid(:,1);
    mumid(2)=(-(Umid(:,2)'*L*Umid(:,2))+sum(V.*(Umid(:,2).^2))+beta*sum(Umid(:,2).^4))/(sum(Umid(:,2).*Umid(:,2)));
    Fmid(:,2)=-V.*Umid(:,2)-beta*Umid(:,2).^3+mumid(2)*Umid(:,2);
    
    Umid(:,3)=M3*Un+tau*A(3,1)*M31*Fmid(:,1)+tau*A(3,2)*M32*Fmid(:,2);
    mumid(3)=(-(Umid(:,3)'*L*Umid(:,3))+sum(V.*(Umid(:,3).^2))+beta*sum(Umid(:,3).^4))/(sum(Umid(:,3).*Umid(:,3)));
    Fmid(:,3)=-V.*Umid(:,3)-beta*Umid(:,3).^3+mumid(3)*Umid(:,3);

    Unext1=Mnext*Un+tau*(b1(1)*Mnext1*Fmid(:,1)+b1(2)*Mnext2*Fmid(:,2)+b1(3)*Mnext3*Fmid(:,3));  d1=Unext1-Un;
    
    if (max(abs(d1))==0)
        gamma=[0;0];
    else 
        Unext2=Mnext*Un+tau*(b2(1)*Mnext1*Fmid(:,1)+b2(2)*Mnext2*Fmid(:,2)+b2(3)*Mnext3*Fmid(:,3));  d2=Unext2-Un;
        gamma=compute_gamma(Energy1(1),Energy2(end),Unext1,d1,d2,h,V,beta,L,Umid,Fmid,tau,b1);
    end
    % fprintf('tn=%d,gamma1=%d,gamma2=%d\n',tn,gamma(1),gamma(2));
    Un_save=Un;  tn_save=tn; 
    Un=Unext1+gamma(1)*d1+gamma(2)*d2;  tn=tn+(1+sum(gamma))*tau;  
    Energy1=[Energy1 h*sum(Un.*Un)];
    Energy2=[Energy2 -h*sum(Un'*L*Un)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4)]; 
    num_of_step=num_of_step+1;
end

if ( (T-tn)<=0 ) 
    Energy1=Energy1(1:end-1);  
    Energy2=Energy2(1:end-1);  
    Un=Un_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end

MM=c(2)*tau*L;  M2=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(c(2)-c(1))*tau*L;  M21=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=c(3)*tau*L;  M3=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(c(3)-c(1))*tau*L;  M31=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(c(3)-c(2))*tau*L;  M32=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=tau*L;  Mnext=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(1-c(1))*tau*L;  Mnext1=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(1-c(2))*tau*L;  Mnext2=II+MM+0.5*MM^2+(1/6)*MM^3;
MM=(1-c(3))*tau*L;  Mnext3=II+MM+0.5*MM^2+(1/6)*MM^3;

Umid(:,1)=Un;
mumid(1)=(-(Umid(:,1)'*L*Umid(:,1))+sum(V.*(Umid(:,1).^2))+beta*sum(Umid(:,1).^4))/(sum(Umid(:,1).*Umid(:,1)));
Fmid(:,1)=-V.*Umid(:,1)-beta*Umid(:,1).^3+mumid(1)*Umid(:,1);

Umid(:,2)=M2*Un+tau*A(2,1)*M21*Fmid(:,1);
mumid(2)=(-(Umid(:,2)'*L*Umid(:,2))+sum(V.*(Umid(:,2).^2))+beta*sum(Umid(:,2).^4))/(sum(Umid(:,2).*Umid(:,2)));
Fmid(:,2)=-V.*Umid(:,2)-beta*Umid(:,2).^3+mumid(2)*Umid(:,2);

Umid(:,3)=M3*Un+tau*A(3,1)*M31*Fmid(:,1)+tau*A(3,2)*M32*Fmid(:,2);
mumid(3)=(-(Umid(:,3)'*L*Umid(:,3))+sum(V.*(Umid(:,3).^2))+beta*sum(Umid(:,3).^4))/(sum(Umid(:,3).*Umid(:,3)));
Fmid(:,3)=-V.*Umid(:,3)-beta*Umid(:,3).^3+mumid(3)*Umid(:,3);

Un=Mnext*Un+tau*(b1(1)*Mnext1*Fmid(:,1)+b1(2)*Mnext2*Fmid(:,2)+b1(3)*Mnext3*Fmid(:,3));  tn=tn+tau;  num_of_step=num_of_step+1;

toc;  CPU_time=toc;
load reference.mat;  err=max(abs(Un-Un_10000));
Energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
ave_step=CPU_time/num_of_step;