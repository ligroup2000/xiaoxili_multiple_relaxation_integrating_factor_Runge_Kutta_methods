function gamma=compute_gamma(Energy1_old,Energy2_old,Unext1,d1,d2,h,V,beta,L,Umid,Fmid,tau,b1)

Unext1Unext1=h*sum(Unext1.*Unext1)-Energy1_old;
Unext1d1=h*sum(Unext1.*d1);
Unext1d2=h*sum(Unext1.*d2);
d1d1=h*sum(d1.*d1);
d2d2=h*sum(d2.*d2);
d1d2=h*sum(d1.*d2);
Utmid=L*Umid+Fmid;  key=-2*tau*h*(sum(Utmid.*Utmid))*b1';
Unext1LUnext1=-h*sum(Unext1'*L*Unext1)-Energy2_old;
Unext1Ld1=-h*sum(Unext1'*L*d1);
Unext1Ld2=-h*sum(Unext1'*L*d2);
d1Ld1=-h*sum(d1'*L*d1);
d2Ld2=-h*sum(d2'*L*d2);
d1Ld2=-h*sum(d1'*L*d2);   

iter_err=1;  iter_count=0;  gamma=[0;0]; 
while ((iter_err>10^(-14)) && (iter_count<5))
    gamma1=gamma(1);  gamma2=gamma(2);
    Un1=Unext1+gamma1*d1+gamma2*d2;  
    Vector=[Unext1Unext1+2*gamma1*Unext1d1+2*gamma2*Unext1d2+gamma1^2*d1d1+gamma2^2*d2d2+2*gamma1*gamma2*d1d2;
            Unext1LUnext1+2*gamma1*Unext1Ld1+2*gamma2*Unext1Ld2+gamma1^2*d1Ld1+gamma2^2*d2Ld2+2*gamma1*gamma2*d1Ld2+h*sum(V.*(Un1.^2)+0.5*beta*(Un1.^4))-(1+gamma1+gamma2)*key];
    Matrix=[2*Unext1d1+2*gamma1*d1d1+2*gamma2*d1d2 2*Unext1d2+2*gamma2*d2d2+2*gamma1*d1d2; ...
            2*Unext1Ld1+2*gamma1*d1Ld1+2*gamma2*d1Ld2+h*sum(2*V.*Un1.*d1+2*beta*(Un1.^3).*d1)-key 2*Unext1Ld2+2*gamma2*d2Ld2+2*gamma1*d1Ld2+h*sum(2*V.*Un1.*d2+2*beta*(Un1.^3).*d2)-key;];
    gamma_save=gamma;  gamma=gamma-Matrix\Vector;
    iter_err=max(abs(gamma_save-gamma));  iter_count=iter_count+1;
end