function [Xmesh,Ymesh,Un,tmesh,Energy1,Energy2,average_time,phi_g0_q,rmsx,rmsy,energy_phi_g,mu_g,tau]=IFRK(tau,p)
tic;  warning off;

Le=-8;  Re=8;  Be=-4;  Te=4;  Nx=16*8;  Ny=8*16;  area=(Re-Le)*(Te-Be);  hx=(Re-Le)/Nx;  hy=(Te-Be)/Ny;  
xmesh=Le+hx:hx:Re-hx;  ymesh=Be+hy:hy:Te-hy;  [Xmesh,Ymesh]=meshgrid(xmesh,ymesh);
freqx=(pi/(Re-Le))*(1:Nx-1)';  freqy=(pi/(Te-Be))*(1:Ny-1)';  [Freqx,Freqy]=meshgrid(freqx,freqy);
Kxxyy=(-1)*(Freqx.^2+Freqy.^2);  L=0.5*Kxxyy;  
gammax=1;  gammay=4;  w0=0;  delta=0;  r0=0;  beta=200;  
V=0.5*gammax^2*Xmesh.^2+0.5*gammay^2*Ymesh.^2+w0*exp(-delta*((Xmesh-r0).^2+Ymesh.^2));

if (p==2)
    A=[0 0;1/2 0];  c=[0;1/2];  b1=[0 1];  b2=[1/2 1/2];  s=size(A,1); 
    Matrix(:,:,1)=exp(c(2)*tau*L);
    Matrix(:,:,2)=exp((c(2)-c(1))*tau*L);
    Matrix(:,:,3)=exp(tau*L);
    Matrix(:,:,4)=exp((1-c(1))*tau*L);
    Matrix(:,:,5)=exp((1-c(2))*tau*L);
elseif (p==3)
    A=[0 0 0;1/3 0 0;0 2/3 0];  c=[0;1/3;2/3];  b1=[1/4 0 3/4];  b2=[1/3 1/3 1/3];  s=size(A,1);
    Matrix(:,:,1)=exp(c(2)*tau*L);
    Matrix(:,:,2)=exp((c(2)-c(1))*tau*L);
    Matrix(:,:,3)=exp(c(3)*tau*L);
    Matrix(:,:,4)=exp((c(3)-c(1))*tau*L);
    Matrix(:,:,5)=exp((c(3)-c(2))*tau*L);
    Matrix(:,:,6)=exp(tau*L);
    Matrix(:,:,7)=exp((1-c(1))*tau*L);
    Matrix(:,:,8)=exp((1-c(2))*tau*L);
    Matrix(:,:,9)=exp((1-c(3))*tau*L);
elseif (p==4)
    A=[0 0 0 0;1/2 0 0 0;0 1/2 0 0;0 0 1 0];  c=[0;1/2;1/2;1];  b1=[1/6 1/3 1/3 1/6];  b2=[0 0 0 1];  s=size(A,1);
    Matrix(:,:,1)=exp(c(2)*tau*L);
    Matrix(:,:,2)=exp((c(2)-c(1))*tau*L);
    Matrix(:,:,3)=exp(c(3)*tau*L);
    Matrix(:,:,4)=exp((c(3)-c(1))*tau*L);
    Matrix(:,:,5)=exp((c(3)-c(2))*tau*L);
    Matrix(:,:,6)=exp(c(4)*tau*L);
    Matrix(:,:,7)=exp((c(4)-c(1))*tau*L);
    Matrix(:,:,8)=exp((c(4)-c(2))*tau*L);
    Matrix(:,:,9)=exp((c(4)-c(3))*tau*L);
    Matrix(:,:,10)=exp(tau*L);
    Matrix(:,:,11)=exp((1-c(1))*tau*L);
    Matrix(:,:,12)=exp((1-c(2))*tau*L);
    Matrix(:,:,13)=exp((1-c(3))*tau*L);
    Matrix(:,:,14)=exp((1-c(4))*tau*L);
end

dstcoe=4/Nx/Ny;  idstcoe=Nx*Ny/4;
Un=(((gammax*gammay)^(1/4))/((pi)^(1/2)))*exp(-0.5*(gammax*xmesh.^2+gammay*Ymesh.^2));  Un_t=dstcoe*dst2(Un);
Energy1=0.25*area*sum(sum(Un_t.*Un_t)); 
Un=idstcoe*idst2(Un_t);  Energy2=(-0.25)*area*sum(sum(Un_t.*L.*Un_t))+hx*hy*sum(sum(V.*(Un.^2)))+0.5*hx*hy*beta*sum(sum(Un.^4));  
tn=0;  tmesh=tn; 

Umid_t=zeros(Ny-1,Nx-1,s);  Umid=zeros(Ny-1,Nx-1,s);  mumid=zeros(1,s);  Fmid=zeros(Ny-1,Nx-1,s);
flag=1;  tol=10^(-4)*tau;
while (flag)
    Umid_t(:,:,1)=Un_t;  Umid(:,:,1)=idstcoe*idst2(Umid_t(:,:,1));
    mumid(1)=((-0.25)*area*sum(sum(Umid_t(:,:,1).*L.*Umid_t(:,:,1)))+hx*hy*sum(sum(V.*(Umid(:,:,1).^2)))+hx*hy*beta*sum(sum(Umid(:,:,1).^4)))/(0.25*area*sum(sum(Umid_t(:,:,1).*Umid_t(:,:,1))));
    Fmid(:,:,1)=dstcoe*dst2(-V.*Umid(:,:,1)-beta*Umid(:,:,1).^3)+mumid(1)*Umid_t(:,:,1);
    for k=2:s
        Umid_t(:,:,k)=Matrix(:,:,(k*(k-1))/2).*Un_t+tau*sum((Matrix(:,:,(k*(k-1))/2+1:(k*(k-1))/2+k-1).*Fmid(:,:,1:k-1)).*(reshape(A(k,1:k-1),1,1,k-1)),3);  Umid(:,:,k)=idstcoe*idst2(Umid_t(:,:,k));
        mumid(k)=((-0.25)*area*sum(sum(Umid_t(:,:,k).*L.*Umid_t(:,:,k)))+hx*hy*sum(sum(V.*(Umid(:,:,k).^2)))+hx*hy*beta*sum(sum(Umid(:,:,k).^4)))/(0.25*area*sum(sum(Umid_t(:,:,k).*Umid_t(:,:,k))));
        Fmid(:,:,k)=dstcoe*dst2(-V.*Umid(:,:,k)-beta*Umid(:,:,k).^3)+mumid(k)*Umid_t(:,:,k);
    end
    Unext1_t=Matrix(:,:,(s*(s+1))/2).*Un_t+tau*sum((Matrix(:,:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid).*(reshape(b1,1,1,s)),3);  d1_t=Unext1_t-Un_t;
    Un_t=Unext1_t;  tn=tn+tau; 
    Un_save=Un;  Un=idstcoe*idst2(Un_t);  
    Energy1=[Energy1 0.25*area*sum(sum(Un_t.*Un_t))];
    Energy2=[Energy2 (-0.25)*area*sum(sum(Un_t.*L.*Un_t))+hx*hy*sum(sum(V.*(Un.^2)))+0.5*hx*hy*beta*sum(sum(Un.^4))]; 
    tmesh=[tmesh tn];
    err=max(max(abs(Un_save-Un)));
    flag=(err >= tol);
    fprintf('tn=%d,err=%d\n',tn,err);
end

toc;  cpu_time=toc;

average_time=cpu_time/(size(tmesh,2)-1);
phi_g0_q=(Un(Ny/2,Nx/2))^2;
rmsx=sqrt(hx*hy*sum(sum((Xmesh.^2).*(Un.^2))));
rmsy=sqrt(hx*hy*sum(sum((Ymesh.^2).*(Un.^2))));
energy_phi_g=Energy2(end);
mu_g=energy_phi_g+0.5*hx*hy*beta*sum(sum(Un.^4));
