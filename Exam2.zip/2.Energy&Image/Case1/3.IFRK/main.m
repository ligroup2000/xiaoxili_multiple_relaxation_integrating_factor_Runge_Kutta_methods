stepsize=[1/1000 1/1000 1/1000];
for p=2:4
    [Xmesh,Ymesh,Un,tmesh,Energy1,Energy2,average_time,phi_g0_q,rmsx,rmsy,energy_phi_g,mu_g,tau]=IFRK(stepsize(p-1),p);
    eval(['DATA' num2str(p) '.XMESH=Xmesh;']);
    eval(['DATA' num2str(p) '.YMESH=Ymesh;']);
    eval(['DATA' num2str(p) '.UN=Un;']);
    eval(['DATA' num2str(p) '.TMESH=tmesh;']);
    eval(['DATA' num2str(p) '.ENERGY1=Energy1;']);
    eval(['DATA' num2str(p) '.ENERGY2=Energy2;']);
    eval(['DATA' num2str(p) '.AVERAGE_TIME=average_time;']);
    eval(['DATA' num2str(p) '.PHI_G0_Q=phi_g0_q;']);
    eval(['DATA' num2str(p) '.RMSX=rmsx;']);
    eval(['DATA' num2str(p) '.RMSY=rmsy;']);
    eval(['DATA' num2str(p) '.ENERGY_PHI_G=energy_phi_g;']);
    eval(['DATA' num2str(p) '.MU_G=mu_g;']);
    eval(['DATA' num2str(p) '.TAU=tau;']);
end
