%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������
kk=1;  kkk=1;
load('RIFRK_old.mat')
Energy12=DATA2.ENERGY1;  tmesh2=DATA2.TMESH;
Energy13=DATA3.ENERGY1;  tmesh3=DATA3.TMESH;
Energy14=DATA4.ENERGY1;  tmesh4=DATA4.TMESH;
y12=abs(Energy12-Energy12(1))/abs(Energy12(1));  y12(y12<kk*10^(-16))=kkk*10^(-16);
y13=abs(Energy13-Energy13(1))/abs(Energy13(1));  y13(y13<kk*10^(-16))=kkk*10^(-16);
y14=abs(Energy14-Energy14(1))/abs(Energy14(1));  y14(y14<kk*10^(-16))=kkk*10^(-16);

semilogy(tmesh2,y12,'r:','LineWidth',1.5);  hold on;
semilogy(tmesh3,y13,'g:','LineWidth',1.5);
semilogy(tmesh4,y14,'b:','LineWidth',1.5); 

load('RIFRK.mat')
Energy12r=DATA2.ENERGY1;  tmesh2r=DATA2.TMESH;
Energy13r=DATA3.ENERGY1;  tmesh3r=DATA3.TMESH;
Energy14r=DATA4.ENERGY1;  tmesh4r=DATA4.TMESH;
y12=abs(Energy12r-Energy12r(1))/abs(Energy12r(1));  y12(y12<kk*10^(-16))=kkk*10^(-16);
y13=abs(Energy13r-Energy13r(1))/abs(Energy13r(1));  y13(y13<kk*10^(-16))=kkk*10^(-16);
y14=abs(Energy14r-Energy14r(1))/abs(Energy14r(1));  y14(y14<kk*10^(-16))=kkk*10^(-16);

p1=semilogy(tmesh2r,y12,'r','LineWidth',3);  hold on;
p2=semilogy(tmesh3r,y13,'g','LineWidth',3);
p3=semilogy(tmesh4r,y14,'b','LineWidth',3); 

% set(gca,'XLim',[0 2.7])
set(gca,'YLim',[10^(-16) 10^(-14)])
% set(gca,'YTick',[10^(-16) 10^(-11) 10^(-6) 10^(-1)]);
% set(gca,'YTicklabel',{'10^{-16}','10^{-11}','10^{-6}','10^{-1}'})
set(gca,'linewidth',2,'FontSize',24)
xlabel('$t$','interpreter','latex','FontSize',30)
ylabel('$|N(\phi_{h,\gamma_{n-1}}^n)-N(\phi_{0,h})|$','interpreter','latex','FontSize',30)
legend([p1,p2,p3],'MRIFRK2', ...
       'MRIFRK3', ...
       'MRIFRK4')
set(legend,'interpreter','latex','location','northwest','FontSize',20) 
