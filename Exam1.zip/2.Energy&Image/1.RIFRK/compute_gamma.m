function [gamma,iter_count]=compute_gamma(Energy1_old,Energy2_old,Unext1_t,d1_t,d2_t,idstcoe,h,V,beta,L,Umid_t,Fmid,tau,area,b1)

Unext1Unext1=0.5*area*sum(Unext1_t.*Unext1_t)-Energy1_old;
Unext1d1=0.5*area*sum(Unext1_t.*d1_t);
Unext1d2=0.5*area*sum(Unext1_t.*d2_t);
d1d1=0.5*area*sum(d1_t.*d1_t);
d2d2=0.5*area*sum(d2_t.*d2_t);
d1d2=0.5*area*sum(d1_t.*d2_t);
Utmid=L.*Umid_t+Fmid;  key=-tau*area*(sum(Utmid.*Utmid))*b1';
Unext1LUnext1=-0.5*area*sum(Unext1_t.*L.*Unext1_t)-Energy2_old;
Unext1Ld1=-0.5*area*sum(Unext1_t.*L.*d1_t);
Unext1Ld2=-0.5*area*sum(Unext1_t.*L.*d2_t);
d1Ld1=-0.5*area*sum(d1_t.*L.*d1_t);
d2Ld2=-0.5*area*sum(d2_t.*L.*d2_t);
d1Ld2=-0.5*area*sum(d1_t.*L.*d2_t);   

iter_err=1;  iter_count=0;  gamma=[0;0];  d1=idstcoe*idst(d1_t);  d2=idstcoe*idst(d2_t);
while ((iter_err>10^(-14)) && (iter_count<10))
    gamma1=gamma(1);  gamma2=gamma(2);
    Un1_t=Unext1_t+gamma1*d1_t+gamma2*d2_t;  Un1=idstcoe*idst(Un1_t);  
    Vector=[Unext1Unext1+2*gamma1*Unext1d1+2*gamma2*Unext1d2+gamma1^2*d1d1+gamma2^2*d2d2+2*gamma1*gamma2*d1d2;
            Unext1LUnext1+2*gamma1*Unext1Ld1+2*gamma2*Unext1Ld2+gamma1^2*d1Ld1+gamma2^2*d2Ld2+2*gamma1*gamma2*d1Ld2+h*sum(V.*(Un1.^2)+0.5*beta*(Un1.^4))-(1+gamma1+gamma2)*key];
    Matrix=[2*Unext1d1+2*gamma1*d1d1+2*gamma2*d1d2 2*Unext1d2+2*gamma2*d2d2+2*gamma1*d1d2; ...
            2*Unext1Ld1+2*gamma1*d1Ld1+2*gamma2*d1Ld2+h*sum(2*V.*Un1.*d1+2*beta*(Un1.^3).*d1)-key 2*Unext1Ld2+2*gamma2*d2Ld2+2*gamma1*d1Ld2+h*sum(2*V.*Un1.*d2+2*beta*(Un1.^3).*d2)-key;];
    gamma_save=gamma;  gamma=gamma-Matrix\Vector;
    iter_err=max(abs(gamma_save-gamma));  iter_count=iter_count+1;
end