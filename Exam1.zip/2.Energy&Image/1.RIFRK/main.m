Beta=[3.1371 12.548 31.371 62.742 156.86 313.71];
Stepsize=[1/40 1/40 1/40 1/40 1/60 1/120];

for k=1:size(Beta,2)
    [beta,xmesh,Un,tmesh,Energy1,Energy2,average_time,phi_g0,rms,energy_phi_g,mu_g,tau,iter_average,ITER]=RIFRK(Beta(k),Stepsize(k));
    eval(['DATA' num2str(k) '.BETA=beta;']);
    eval(['DATA' num2str(k) '.XMESH=xmesh;']);
    eval(['DATA' num2str(k) '.UN=Un;']);
    eval(['DATA' num2str(k) '.TMESH=tmesh;']);
    eval(['DATA' num2str(k) '.ENERGY1=Energy1;']);
    eval(['DATA' num2str(k) '.ENERGY2=Energy2;']);
    eval(['DATA' num2str(k) '.AVERAGE_TIME=average_time;']);
    eval(['DATA' num2str(k) '.PHI_G0=phi_g0;']);
    eval(['DATA' num2str(k) '.RMS=rms;']);
    eval(['DATA' num2str(k) '.ENERGY_PHI_G=energy_phi_g;']);
    eval(['DATA' num2str(k) '.MU_G=mu_g;']);
    eval(['DATA' num2str(k) '.TAU=tau;']);
    eval(['DATA' num2str(k) '.iter_average=iter_average;']);
    eval(['DATA' num2str(k) '.ITER=ITER;']);
end
