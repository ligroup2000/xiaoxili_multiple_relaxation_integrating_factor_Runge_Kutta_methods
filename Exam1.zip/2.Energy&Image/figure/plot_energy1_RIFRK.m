%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

kk=1;  kkk=1;

load('RIFRK_old.mat')
Energy11o=DATA1.ENERGY1;  tmesh1o=DATA1.TMESH;
Energy12o=DATA2.ENERGY1;  tmesh2o=DATA2.TMESH;
Energy13o=DATA3.ENERGY1;  tmesh3o=DATA3.TMESH;
Energy14o=DATA4.ENERGY1;  tmesh4o=DATA4.TMESH;
Energy15o=DATA5.ENERGY1;  tmesh5o=DATA5.TMESH;
Energy16o=DATA6.ENERGY1;  tmesh6o=DATA6.TMESH;
y1o=abs(Energy11o-Energy11o(1));  y1o(y1o<kk*10^(-16))=kkk*10^(-16);
y2o=abs(Energy12o-Energy12o(1));  y2o(y2o<kk*10^(-16))=kkk*10^(-16);
y3o=abs(Energy13o-Energy13o(1));  y3o(y3o<kk*10^(-16))=kkk*10^(-16);
y4o=abs(Energy14o-Energy14o(1));  y4o(y4o<kk*10^(-16))=kkk*10^(-16);
y5o=abs(Energy15o-Energy15o(1));  y5o(y5o<kk*10^(-16))=kkk*10^(-16);
y6o=abs(Energy16o-Energy16o(1));  y6o(y6o<kk*10^(-16))=kkk*10^(-16);

semilogy(tmesh1o,y1o,'k:','LineWidth',1.5); hold on; 
semilogy(tmesh2o,y2o,'b:','LineWidth',1.5);
semilogy(tmesh3o,y3o,'g:','LineWidth',1.5);
semilogy(tmesh4o,y4o,'c:','LineWidth',1.5);
semilogy(tmesh5o,y5o,'r:','LineWidth',1.5);
semilogy(tmesh6o,y6o,'m:','LineWidth',1.5);

load('RIFRK.mat')
Energy11=DATA1.ENERGY1;  tmesh1=DATA1.TMESH;
Energy12=DATA2.ENERGY1;  tmesh2=DATA2.TMESH;
Energy13=DATA3.ENERGY1;  tmesh3=DATA3.TMESH;
Energy14=DATA4.ENERGY1;  tmesh4=DATA4.TMESH;
Energy15=DATA5.ENERGY1;  tmesh5=DATA5.TMESH;
Energy16=DATA6.ENERGY1;  tmesh6=DATA6.TMESH;

y1=abs(Energy11-Energy11(1));  y1(y1<kk*10^(-16))=kkk*10^(-16);
y2=abs(Energy12-Energy12(1));  y2(y2<kk*10^(-16))=kkk*10^(-16);
y3=abs(Energy13-Energy13(1));  y3(y3<kk*10^(-16))=kkk*10^(-16);
y4=abs(Energy14-Energy14(1));  y4(y4<kk*10^(-16))=kkk*10^(-16);
y5=abs(Energy15-Energy15(1));  y5(y5<kk*10^(-16))=kkk*10^(-16);
y6=abs(Energy16-Energy16(1));  y6(y6<kk*10^(-16))=kkk*10^(-16);

p1=semilogy(tmesh1,y1,'k','LineWidth',3); hold on; 
p2=semilogy(tmesh2,y2,'b','LineWidth',3);
p3=semilogy(tmesh3,y3,'g','LineWidth',3);
p4=semilogy(tmesh4,y4,'c','LineWidth',3);
p5=semilogy(tmesh5,y5,'r','LineWidth',3);
p6=semilogy(tmesh6,y6,'m','LineWidth',3);


set(gca,'YLim',[10^(-16) 1.5*10^(-14)])
set(gca,'linewidth',2,'FontSize',24)
xlabel('$t$','interpreter','latex','FontSize',30)
ylabel('$|N(\phi_{h,\gamma_{n-1}}^n)-N(\phi_{0,h})|$','interpreter','latex','FontSize',30)
legend([p1,p2,p3,p4,p5,p6],'$\beta=3.1371,\tau=1/40$', ...
       '$\beta=12.548,\tau=1/40$', ...
       '$\beta=31.371,\tau=1/40$', ...
       '$\beta=62.742,\tau=1/40$', ...
       '$\beta=156.86,\tau=1/60$', ...
       '$\beta=313.71,\tau=1/120$')
set(legend,'interpreter','latex','location','northwest','FontSize',20) 