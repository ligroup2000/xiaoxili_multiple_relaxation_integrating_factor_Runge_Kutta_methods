function det_B=compute_det_B(Un_t,p,beta)

Le=-16;  Re=16;  N=256;  area=Re-Le;  h=(Re-Le)/N;  xmesh=Le+h:h:Re-h;  xmesh=xmesh';
freq=(pi/(Re-Le))*(1:N-1)';  Kxx=(-1)*(freq.^2);  L=0.5*Kxx;  V=0.5*xmesh.^2;

    tau=1/10000;
    
    if (p==2)
        A=[0 0;1/2 0];  c=[0;1/2];  b1=[0 1];  
        b2=[1/2 1/2];
        Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
                exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L)];
    elseif (p==3)
        A=[0 0 0;1/3 0 0;0 2/3 0];  c=[0;1/3;2/3];  b1=[1/4 0 3/4];  
        b2=[1/3 1/3 1/3];
        Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
                exp(c(3)*tau*L) exp((c(3)-c(1))*tau*L) exp((c(3)-c(2))*tau*L) ...
                exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L) exp((1-c(3))*tau*L)];
    elseif (p==4)
        A=[0 0 0 0;1/2 0 0 0;0 1/2 0 0;0 0 1 0];  c=[0;1/2;1/2;1];  b1=[1/6 1/3 1/3 1/6];  
        b2=[0 0 0 1];
        Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
                exp(c(3)*tau*L) exp((c(3)-c(1))*tau*L) exp((c(3)-c(2))*tau*L) ...
                exp(c(4)*tau*L) exp((c(4)-c(1))*tau*L) exp((c(4)-c(2))*tau*L) exp((c(4)-c(3))*tau*L) ...
                exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L) exp((1-c(3))*tau*L) exp((1-c(4))*tau*L)];
    end

    s=size(A,1);  dstcoe=2/N;  idstcoe=N/2;

    Umid_t=zeros(N-1,s);  Umid=zeros(N-1,s);  mumid=zeros(1,s);  Fmid=zeros(N-1,s); 

    Umid_t(:,1)=Un_t;  Umid(:,1)=idstcoe*idst(Umid_t(:,1));
    mumid(1)=((-0.5)*area*sum(Umid_t(:,1).*L.*Umid_t(:,1))+h*sum(V.*(Umid(:,1).^2))+h*beta*sum(Umid(:,1).^4))/(0.5*area*sum(Umid_t(:,1).*Umid_t(:,1)));
    Fmid(:,1)=dstcoe*dst(-V.*Umid(:,1)-beta*Umid(:,1).^3)+mumid(1)*Umid_t(:,1);
    for k=2:s
        Umid_t(:,k)=Matrix(:,(k*(k-1))/2).*Un_t+tau*(Matrix(:,(k*(k-1))/2+1:(k*(k-1))/2+k-1).*Fmid(:,1:k-1))*(A(k,1:k-1))';  Umid(:,k)=idstcoe*idst(Umid_t(:,k));
        mumid(k)=((-0.5)*area*sum(Umid_t(:,k).*L.*Umid_t(:,k))+h*sum(V.*(Umid(:,k).^2))+h*beta*sum(Umid(:,k).^4))/(0.5*area*sum(Umid_t(:,k).*Umid_t(:,k)));
        Fmid(:,k)=dstcoe*dst(-V.*Umid(:,k)-beta*Umid(:,k).^3)+mumid(k)*Umid_t(:,k);
    end
    Unext1_t=Matrix(:,(s*(s+1))/2).*Un_t+tau*(Matrix(:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid)*b1';  d1_t=Unext1_t-Un_t;
    Unext2_t=Matrix(:,(s*(s+1))/2).*Un_t+tau*(Matrix(:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid)*b2';  d2_t=Unext2_t-Un_t;

    Unext1d1=0.5*area*sum(Unext1_t.*d1_t);
    Unext1d2=0.5*area*sum(Unext1_t.*d2_t);
    Utmid=L.*Umid_t+Fmid;  key=-tau*area*(sum(Utmid.*Utmid))*b1';
    Unext1Ld1=-0.5*area*sum(Unext1_t.*L.*d1_t);
    Unext1Ld2=-0.5*area*sum(Unext1_t.*L.*d2_t); 

    Un1_t=Unext1_t;  Un1=idstcoe*idst(Un1_t);
    d1=idstcoe*idst(d1_t);  d2=idstcoe*idst(d2_t);
    BB=(1/tau/tau)*[2*Unext1d1 2*Unext1d2; ...
                    2*Unext1Ld1+2*h*sum(V.*Un1.*d1)+2*beta*h*sum((Un1.^3).*d1)-key 2*Unext1Ld2+2*h*sum(V.*Un1.*d2)+2*beta*h*sum((Un1.^3).*d2)-key;];
    det_B=det(BB); 