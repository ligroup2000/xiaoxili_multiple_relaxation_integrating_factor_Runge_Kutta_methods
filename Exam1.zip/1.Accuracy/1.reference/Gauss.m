function Un_t=Gauss(tau)

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

T=0.5;  Le=-16;  Re=16;  N=32*8;  area=Re-Le;  h=(Re-Le)/N;  xmesh=Le+h:h:Re-h;  xmesh=xmesh';
freq=(pi/(Re-Le))*(1:N-1)';  Kxx=(-1)*(freq.^2);  L=0.5*Kxx;  V=0.5*xmesh.^2;  beta=10;

dstcoe=2/N;  idstcoe=N/2;
Un=(1/((pi)^(1/4)))*exp(-0.5*(xmesh.^2));  Un_t=dstcoe*dst(Un);   

s=size(A,1);  Matrix=(speye(s*(N-1))-tau*kron(A,spdiags(L(:),0,N-1,N-1)))^(-1);  
for k=1:round(T/tau)
    iter_err=1;  iter_count=0;  eUn_t=kron(ones(s,1),Un_t);  Umid_t=eUn_t;
    while ((iter_err>10^(-14)) && (iter_count<100))
        Umid_t_reshape=reshape(Umid_t,N-1,s);  Umid_reshape=idstcoe*idst(Umid_t_reshape);  
        fmid_t_reshape=dstcoe*dst(-V.*Umid_reshape-beta*Umid_reshape.^3);
        mumid=((-0.5)*area*sum(Umid_t_reshape.*L.*Umid_t_reshape)+h*sum(V.*Umid_reshape.^2)+h*beta*sum(Umid_reshape.^4)) ...
              ./(0.5*area*sum(Umid_t_reshape.^2));
        Fmid_t_reshape=fmid_t_reshape+Umid_t_reshape*diag(mumid);
        Gmid=Fmid_t_reshape*A';
        Umid_t_save=Umid_t;  Umid_t=Matrix*(eUn_t+tau*Gmid(:));
        iter_err=max(abs(Umid_t_save-Umid_t));  
        iter_count=iter_count+1;
    end
    iter_err
    k
    Umid_t_reshape=reshape(Umid_t,N-1,s);  Umid_reshape=idstcoe*idst(Umid_t_reshape);
    fmid_t_reshape=dstcoe*dst(-V.*Umid_reshape-beta*Umid_reshape.^3);
    mumid=((-0.5)*area*sum(Umid_t_reshape.*L.*Umid_t_reshape)+h*sum(V.*Umid_reshape.^2)+h*beta*sum(Umid_reshape.^4)) ...
          ./(0.5*area*sum(Umid_t_reshape.^2));
    Fmid_t_reshape=fmid_t_reshape+Umid_t_reshape*diag(mumid);
    Un_t=Un_t+tau*L.*Umid_t_reshape*b'+tau*Fmid_t_reshape*b';
end