function [err,gamma1_average,gamma2_average,gamma_average,S1_average,S2_average,S_average,Energy1_average,DET_min]=RIFRK(tau,p)

T=0.5;  Le=-16;  Re=16;  N=256;  area=Re-Le;  h=(Re-Le)/N;  xmesh=Le+h:h:Re-h;  xmesh=xmesh';
freq=(pi/(Re-Le))*(1:N-1)';  Kxx=(-1)*(freq.^2);  L=0.5*Kxx;  V=0.5*xmesh.^2;  beta=10; 

if (p==2)
    A=[0 0;1/2 0];  c=[0;1/2];  b1=[0 1];  
    b2=[1/2 1/2];
    Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
            exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L)];
elseif (p==3)
    A=[0 0 0;1/3 0 0;0 2/3 0];  c=[0;1/3;2/3];  b1=[1/4 0 3/4];  
    b2=[1/3 1/3 1/3];
    Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
            exp(c(3)*tau*L) exp((c(3)-c(1))*tau*L) exp((c(3)-c(2))*tau*L) ...
            exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L) exp((1-c(3))*tau*L)];
elseif (p==4)
    A=[0 0 0 0;1/2 0 0 0;0 1/2 0 0;0 0 1 0];  c=[0;1/2;1/2;1];  b1=[1/6 1/3 1/3 1/6];  
    b2=[0 0 0 1];
    Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
            exp(c(3)*tau*L) exp((c(3)-c(1))*tau*L) exp((c(3)-c(2))*tau*L) ...
            exp(c(4)*tau*L) exp((c(4)-c(1))*tau*L) exp((c(4)-c(2))*tau*L) exp((c(4)-c(3))*tau*L) ...
            exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L) exp((1-c(3))*tau*L) exp((1-c(4))*tau*L)];
end

s=size(A,1);  dstcoe=2/N;  idstcoe=N/2;
Un=(1/((pi)^(1/4)))*exp(-0.5*(xmesh.^2));  Un_t=dstcoe*dst(Un);
Energy1=0.5*area*sum(Un_t.*Un_t); 
Un=idstcoe*idst(Un_t);  Energy2=(-0.5)*area*sum(Un_t.*L.*Un_t)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4);  
tn=0;  tmesh=tn;  
GAMMA1=[];  GAMMA2=[];  
S1=[];  S2=[];  DET=[];

Umid_t=zeros(N-1,s);  Umid=zeros(N-1,s);  mumid=zeros(1,s);  Fmid=zeros(N-1,s);
while (tn<(T-tau))
    Umid_t(:,1)=Un_t;  Umid(:,1)=idstcoe*idst(Umid_t(:,1));
    mumid(1)=((-0.5)*area*sum(Umid_t(:,1).*L.*Umid_t(:,1))+h*sum(V.*(Umid(:,1).^2))+h*beta*sum(Umid(:,1).^4))/(0.5*area*sum(Umid_t(:,1).*Umid_t(:,1)));
    Fmid(:,1)=dstcoe*dst(-V.*Umid(:,1)-beta*Umid(:,1).^3)+mumid(1)*Umid_t(:,1);
    for k=2:s
        Umid_t(:,k)=Matrix(:,(k*(k-1))/2).*Un_t+tau*(Matrix(:,(k*(k-1))/2+1:(k*(k-1))/2+k-1).*Fmid(:,1:k-1))*(A(k,1:k-1))';  Umid(:,k)=idstcoe*idst(Umid_t(:,k));
        mumid(k)=((-0.5)*area*sum(Umid_t(:,k).*L.*Umid_t(:,k))+h*sum(V.*(Umid(:,k).^2))+h*beta*sum(Umid(:,k).^4))/(0.5*area*sum(Umid_t(:,k).*Umid_t(:,k)));
        Fmid(:,k)=dstcoe*dst(-V.*Umid(:,k)-beta*Umid(:,k).^3)+mumid(k)*Umid_t(:,k);
    end
    Unext1_t=Matrix(:,(s*(s+1))/2).*Un_t+tau*(Matrix(:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid)*b1';  d1_t=Unext1_t-Un_t;
    S1=[S1 abs(0.5*area*sum(Unext1_t.*Unext1_t)-Energy1(1))];
    Unext1=idstcoe*idst(Unext1_t);  Utmid=L.*Umid_t+Fmid;  key=-tau*area*(sum(Utmid.*Utmid))*b1';  
    S2=[S2 abs((-0.5)*area*sum(Unext1_t.*L.*Unext1_t)+h*sum(V.*(Unext1.^2))+0.5*h*beta*sum(Unext1.^4)-Energy2(end)-key)];
    if (max(abs(d1_t))==0)
        gamma=[0;0];
    else 
        Unext2_t=Matrix(:,(s*(s+1))/2).*Un_t+tau*(Matrix(:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid)*b2';  d2_t=Unext2_t-Un_t;
        gamma=compute_gamma(Energy1(1),Energy2(end),Unext1_t,d1_t,d2_t,idstcoe,h,V,beta,L,Umid_t,Fmid,tau,area,b1);
        DET=[DET compute_det_B(Un_t,p,beta)];
    end
    fprintf('tn=%d,gamma1=%d,gamma2=%d\n',tn,gamma(1),gamma(2));
    GAMMA1=[GAMMA1 gamma(1)];  GAMMA2=[GAMMA2 gamma(2)];
    Un_t_save=Un_t;  tn_save=tn; 
    Un_t=Unext1_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+sum(gamma))*tau;  Un=idstcoe*idst(Un_t);  
    Energy1=[Energy1 0.5*area*sum(Un_t.*Un_t)];
    Energy2=[Energy2 (-0.5)*area*sum(Un_t.*L.*Un_t)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4)]; 
    tmesh=[tmesh tn];
end

if ( (T-tn)<=0 )
    GAMMA1=GAMMA1(1:end-1);  
    GAMMA2=GAMMA2(1:end-1);  
    Energy1=Energy1(1:end-1);  
    Energy2=Energy2(1:end-1);  
    tmesh=tmesh(1:end-1);
    Un_t=Un_t_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end

if (p==2)
    Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ....
            exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L)];
elseif (p==3)
    Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
            exp(c(3)*tau*L) exp((c(3)-c(1))*tau*L) exp((c(3)-c(2))*tau*L) ...
            exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L) exp((1-c(3))*tau*L)];
elseif (p==4)
    Matrix=[exp(c(2)*tau*L) exp((c(2)-c(1))*tau*L) ...
            exp(c(3)*tau*L) exp((c(3)-c(1))*tau*L) exp((c(3)-c(2))*tau*L) ...
            exp(c(4)*tau*L) exp((c(4)-c(1))*tau*L) exp((c(4)-c(2))*tau*L) exp((c(4)-c(3))*tau*L) ...
            exp(tau*L) exp((1-c(1))*tau*L) exp((1-c(2))*tau*L) exp((1-c(3))*tau*L) exp((1-c(4))*tau*L)];
end

Umid_t(:,1)=Un_t;  Umid(:,1)=idstcoe*idst(Umid_t(:,1));
mumid(1)=((-0.5)*area*sum(Umid_t(:,1).*L.*Umid_t(:,1))+h*sum(V.*(Umid(:,1).^2))+h*beta*sum(Umid(:,1).^4))/(0.5*area*sum(Umid_t(:,1).*Umid_t(:,1)));
Fmid(:,1)=dstcoe*dst(-V.*Umid(:,1)-beta*Umid(:,1).^3)+mumid(1)*Umid_t(:,1);
for k=2:s
    Umid_t(:,k)=Matrix(:,(k*(k-1))/2).*Un_t+tau*(Matrix(:,(k*(k-1))/2+1:(k*(k-1))/2+k-1).*Fmid(:,1:k-1))*(A(k,1:k-1))';
    Umid(:,k)=idstcoe*idst(Umid_t(:,k));
    mumid(k)=((-0.5)*area*sum(Umid_t(:,k).*L.*Umid_t(:,k))+h*sum(V.*(Umid(:,k).^2))+h*beta*sum(Umid(:,k).^4))/(0.5*area*sum(Umid_t(:,k).*Umid_t(:,k)));
    Fmid(:,k)=dstcoe*dst(-V.*Umid(:,k)-beta*Umid(:,k).^3)+mumid(k)*Umid_t(:,k);
end
Un_t=Matrix(:,(s*(s+1))/2).*Un_t+tau*(Matrix(:,(s*(s+1))/2+1:(s*(s+1))/2+s).*Fmid)*(b1)';  tn=tn+tau;

load reference.mat;  err=max(abs(Un_t-Un_t_10000));
gamma1_average=mean(abs(GAMMA1));  
gamma2_average=mean(abs(GAMMA2));
gamma_average=mean([gamma1_average gamma2_average]);
S1_average=mean(S1);
S2_average=mean(S2);
S_average=mean([S1_average S2_average]);
Energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
DET_min=min(abs(DET));