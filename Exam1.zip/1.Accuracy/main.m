stepsize=[1/40 1/80 1/160 1/320];

ERR=[];  GAMMA1=[];  GAMMA2=[];  GAMMA=[];  S1=[];  S2=[];  S=[];  Energy1=[];  DET_MIN=[];
for k=1:size(stepsize,2)
    [err,gamma1_average,gamma2_average,gamma_average,S1_average,S2_average,S_average,Energy1_average,DET_min]=RIFRK(stepsize(k),2);
    ERR=[ERR err];
    GAMMA1=[GAMMA1 gamma1_average];
    GAMMA2=[GAMMA2 gamma2_average];
    GAMMA=[GAMMA gamma_average];
    S1=[S1 S1_average];
    S2=[S2 S2_average];
    S=[S S_average];
    Energy1=[Energy1 Energy1_average];
    DET_MIN=[DET_MIN DET_min];
end

err_order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
gamma1_order=log(GAMMA1(1:end-1)./GAMMA1(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
gamma2_order=log(GAMMA2(1:end-1)./GAMMA2(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
gamma_order=log(GAMMA(1:end-1)./GAMMA(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
S1_order=log(S1(1:end-1)./S1(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
S2_order=log(S2(1:end-1)./S2(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
S_order=log(S(1:end-1)./S(2:end))./log(stepsize(1:end-1)./stepsize(2:end))