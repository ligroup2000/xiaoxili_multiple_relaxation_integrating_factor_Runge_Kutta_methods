function [tau,p,stepsize]=RRK(tau,p)

Le=-16;  Re=16;  N=256;  area=Re-Le;  h=(Re-Le)/N;  xmesh=Le+h:h:Re-h;  xmesh=xmesh';
freq=(pi/(Re-Le))*(1:N-1)';  Kxx=(-1)*(freq.^2);  L=5*Kxx;  V=0.5*xmesh.^2;  beta=1; 

if (p==2)
    A=[0 0;1/2 0];  c=[0;1/2];  b1=[0 1];  
    b2=[1/2 1/2];
elseif (p==3)
    A=[0 0 0;1/3 0 0;0 2/3 0];  c=[0;1/3;2/3];  b1=[1/4 0 3/4];  
    b2=[1/3 1/3 1/3];
elseif (p==4)
    A=[0 0 0 0;1/2 0 0 0;0 1/2 0 0;0 0 1 0];  c=[0;1/2;1/2;1];  b1=[1/6 1/3 1/3 1/6];  
    b2=[0 0 0 1];
end

s=size(A,1);  dstcoe=2/N;  idstcoe=N/2;
Un=(1/((pi)^(1/4)))*exp(-0.5*(xmesh.^2));  Un_t=dstcoe*dst(Un);
Energy1=0.5*area*sum(Un_t.*Un_t); 
Un=idstcoe*idst(Un_t);  Energy2=(-0.5)*area*sum(Un_t.*L.*Un_t)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4);  
tn=0;  tmesh=tn;  stepsize=[];

Umid_t=zeros(N-1,s);  Umid=zeros(N-1,s);  mumid=zeros(1,s);  Fmid=zeros(N-1,s);
for kk=1:50
    Umid_t(:,1)=Un_t;  Umid(:,1)=idstcoe*idst(Umid_t(:,1));
    mumid(1)=((-0.5)*area*sum(Umid_t(:,1).*L.*Umid_t(:,1))+h*sum(V.*(Umid(:,1).^2))+h*beta*sum(Umid(:,1).^4))/(0.5*area*sum(Umid_t(:,1).*Umid_t(:,1)));
    Fmid(:,1)=L.*Umid_t(:,1)+dstcoe*dst(-V.*Umid(:,1)-beta*Umid(:,1).^3)+mumid(1)*Umid_t(:,1);
    for k=2:s
        Umid_t(:,k)=Un_t+tau*Fmid(:,1:k-1)*(A(k,1:k-1))';  Umid(:,k)=idstcoe*idst(Umid_t(:,k));
        mumid(k)=((-0.5)*area*sum(Umid_t(:,k).*L.*Umid_t(:,k))+h*sum(V.*(Umid(:,k).^2))+h*beta*sum(Umid(:,k).^4))/(0.5*area*sum(Umid_t(:,k).*Umid_t(:,k)));
        Fmid(:,k)=L.*Umid_t(:,k)+dstcoe*dst(-V.*Umid(:,k)-beta*Umid(:,k).^3)+mumid(k)*Umid_t(:,k);
    end
    Unext1_t=Un_t+tau*Fmid*b1';  d1_t=Unext1_t-Un_t;
    if (max(abs(d1_t))==0)
        gamma=[0;0];
    else 
        Unext2_t=Un_t+tau*Fmid*b2';  d2_t=Unext2_t-Un_t;
        gamma=compute_gamma(Energy1(1),Energy2(end),Unext1_t,d1_t,d2_t,idstcoe,h,V,beta,L,Fmid,tau,area,b1);
    end
    fprintf('tn=%d,gamma1=%d,gamma2=%d\n',tn,gamma(1),gamma(2));
    Un_t=Unext1_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+sum(gamma))*tau;  Un=idstcoe*idst(Un_t);  
    Energy1=[Energy1 0.5*area*sum(Un_t.*Un_t)];
    Energy2=[Energy2 (-0.5)*area*sum(Un_t.*L.*Un_t)+h*sum(V.*(Un.^2))+0.5*h*beta*sum(Un.^4)]; 
    tmesh=[tmesh tn];  stepsize=[stepsize (1+sum(gamma))*tau];
end
